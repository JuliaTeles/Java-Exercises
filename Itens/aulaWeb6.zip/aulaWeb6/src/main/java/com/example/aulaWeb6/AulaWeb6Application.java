package com.example.aulaWeb6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AulaWeb6Application {

	public static void main(String[] args) {
		SpringApplication.run(AulaWeb6Application.class, args);
	}

}
